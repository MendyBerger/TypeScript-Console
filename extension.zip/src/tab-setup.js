chrome.devtools.panels.create("TS Console",
    null,
    "tab.html",
    null
);

console.log("from: tab.js");
